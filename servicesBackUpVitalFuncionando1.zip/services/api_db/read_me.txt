Para que funcione la api rest con endpoints debe usar slim micro framework, instalandola desde composer

1. Debe ubicarse en la carpeta del proyecto e instalar slim (composer debe estar instalado previamente) desde la consola de comandos

composer require slim/slim

2. Debe tener una subcarpeta denominada src, y un archivo denominado routes.php que contendrá las rutas de los endpoints