import Dropdown from './Dropdown.vue';

module.exports = {
  install: function (Vue, options) {
    Vue.component('Dropdown', Dropdown);
  }
};
